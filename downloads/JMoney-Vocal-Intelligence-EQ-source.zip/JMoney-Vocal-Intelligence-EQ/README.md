# J Money — Vocal Intelligence EQ

Original C++20/JUCE VST3 effect for rap vocals. Development build, not a finished commercial release. See [feature status](docs/STATUS.md) and [validation](docs/VALIDATION.md) before use.

Real DSP: 24 parametric/dynamic bands, seven filter types, stereo/L/R/M/S routing, vocal macros, conservative filter-bank spectral learning, local reference targets, optional static linear-phase FIR, cross-process spectral group unmasking. No online inference, GPU, subscription, limiter, compression, pitch correction, or denoising. Not affiliated with Sonible; no proprietary algorithm, model, preset, or artwork is included. Audio results are not claimed to match smart:EQ 4.

A compiled **Windows x64 development bundle** is now provided in `dist/JMoney-Vocal-Intelligence-EQ-Windows-x64.zip`. See [installation](docs/INSTALL-WINDOWS.txt) and [Windows build evidence](docs/WINDOWS-BUILD.md). Windows binaries were validated under Wine; Audition itself remains untested.

## Windows x64 Release build

Install Visual Studio 2022 Build Tools with Desktop development with C++, Windows SDK, Git, and CMake >=3.22. From PowerShell:

```powershell
./scripts/build-windows.ps1
```

JUCE is fetched at exact commit `51a8a6d7aeae7326956d747737ccf1575e61e209` (8.0.6). CMake uses JUCE's bundled VST3 SDK. No separate SDK download is required. Build produces a genuine JUCE VST3 bundle under `build-win/JMoney_artefacts/Release/VST3/`. GitHub Actions workflow builds the same configuration; workflow inclusion is not evidence of a successful Windows run.

Portable DSP-only validation without JUCE:

```sh
cmake -S . -B build-core -DJM_CORE_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core
ctest --test-dir build-core --output-on-failure
```

Linux full build requires standard JUCE X11, ALSA, FreeType, and Fontconfig development dependencies. Build with `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release`, then `cmake --build build --parallel 2` and `ctest --test-dir build --output-on-failure`.

## Install and remove

After a successful **Windows** build, close audio hosts and copy the entire `J Money - Vocal Intelligence EQ.vst3` bundle to `C:\Program Files\Common Files\VST3` (administrator rights may be needed). Do not rename a `.so` or DLL into a VST3. Linux artifacts cannot load on Windows.

In Audition, use **Effects > Audio Plug-In Manager > Scan for Plug-ins**, then enable the entry. This is the requested scanning procedure; current Adobe documentation could not be verified here because Adobe returned HTTP 403. Verify the labels in your installed Audition version. See [Audition checklist](docs/AUDITION.md).

To remove, close Audition, delete the installed bundle, and rescan. Back up user `.jmveq` presets separately. If scanning fails, confirm x64 architecture, complete bundle copy, Release configuration, Visual C++ runtime availability, and host scan logs. Do not install the Linux build on Windows.

## Rap-vocal quick start

1. Begin with **J Money — Natural Rap Lead** on an isolated lead vocal. Lower the track level first if it clips.
2. Play a representative verse containing low and high notes. Press Learn and provide at least 12 seconds of accepted nonsilent audio. Silence does not advance progress.
3. Keep `learn_amount` near 0.25–0.35. Increase cuts before boosts. Listen for lost chest/body; reduce rumble or high-pass frequency when the voice gets thin.
4. Use mud/nasal controls only when those problems are audible. Add modest presence; use harshness and sibilance controls to reduce transient excess.
5. Compare with auto gain enabled and A/B. Output trim is still needed if the output exceeds 0 dBFS. There is no clipping prevention or hidden limiter.
6. For a beat, load **Beat — Make Room for Lead** and give both instances the same unique group name. Lead tier Foreground; beat Background. Select Combined on the beat. Without an active foreground peer, group unmasking contributes zero reduction.
7. Stop playback before changing linear-phase mode. Prefer minimum phase for recording and older CPUs. Review offline exports: group coordination cannot see tracks lacking an instance.

See [DSP and limitations](docs/DSP.md), [presets](docs/PRESETS.md), and [licenses](THIRD_PARTY_NOTICES.md).
